<div id="preloader">
    <div id="status"></div>
</div>